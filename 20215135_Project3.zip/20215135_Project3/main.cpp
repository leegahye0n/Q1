#include <iostream>
using namespace std;

class Vector
{
private:
	float x, y, z;
public:
	Vector() {}
	Vector(float x, float y, float z) :x{ x }, y{ y }, z{ z } {}

	Vector operator+() const {
		return Vector(+x, +y, +z);
	}

	Vector operator-(const Vector& v) const {
		return Vector{ x - v.x, y - v.y, z - v.z };
	}

	Vector operator/(float n) const {
		return Vector{ x / n, y / n, z / n };
	}

	void print() {
		cout << x << " " << y << " " << z << endl;
	}
};

int main() {
	Vector v0{ 1,2,3 };
	Vector v1{ 1,2,3 };

	Vector v2 = +v0;
	v2.print();

	Vector v3 = v0.operator-(v1);
	v3.print();

	Vector v4 = v1 / 3.0f;
	v4.print();
}